<?php
if (!defined("WHMCS")) die("This file cannot be accessed directly");
use WHMCS\Database\Capsule;
 
function getParams($vars) {
  $array = array('action' => array(), 'params' => array());
  if(isset($vars['cmd'])) {
    //Local API mode
    $array['action'] = $vars['cmd'];
    $array['params'] = (object)$vars['apivalues1'];
    $array['adminuser'] = $vars['adminuser'];
 
  } else {
    //Post CURL mode
    $array['action'] = $vars['_POST']['action'];
    unset($vars['_POST']['username']);
    unset($vars['_POST']['password']);
    unset($vars['_POST']['action']);
	unset($vars['_POST']['accesskey']);
	unset($vars['_POST']['responsetype']);
    $array['params'] = (object)$vars['_POST'];
  }
  return (object)$array;
}
 
try {
	if ($silent == true) { 
	$vars = get_defined_vars();
	//Get the parameters
	$request = getParams($vars);
	
	$pid = json_decode($request->params->pid);
	$cid = json_decode($request->params->clientid);
	if(is_array($pid))
	{
		$index = 0;
		foreach ($pid as $value)
		{
			if($index == 0)
			{
				$sqlstr = "(SELECT IFNULL(packageid,$value) as pid, IFNULL(COUNT(id),0) as total FROM tblhosting WHERE userid=".intval($cid)." AND packageid = ? AND domainstatus='Active')";
			}
			else
			{
				$sqlstr = $sqlstr . " UNION " . "(SELECT IFNULL(packageid,$value) as pid, IFNULL(COUNT(id),0) as total FROM tblhosting WHERE userid=".intval($cid)." AND packageid = ? AND domainstatus='Active')";
			}
			$index++;
		}
		$query = Capsule::select($sqlstr,$pid);
	}
	else
	{
		$query = Capsule::select("SELECT IFNULL(packageid,$pid) as pid, IFNULL(COUNT(id),0) as total FROM `tblhosting` WHERE userid=".intval($cid)." AND packageid= ? AND domainstatus='Active'", array(intval($pid)));
	}
	
	$apiresults =  array(
      "result" => "success",
      "products" => $query
      );
	}
} catch (Exception $e) {
	$apiresults = array("result" => "error", "message" => $pid . $e->getMessage());
}
?>