<?php
/**
 * Example Hook Function
 *
 * Please refer to the documentation @ http://docs.whmcs.com/Hooks for more information
 * The code in this hook is commented out by default. Uncomment to use.
 *
 * @package    WHMCS
 * @author     WHMCS Limited <development@whmcs.com>
 * @copyright  Copyright (c) WHMCS Limited 2005-2013
 * @license    http://www.whmcs.com/license/ WHMCS Eula
 * @version    $Id$
 * @link       http://www.whmcs.com/
 */

/*

if (!defined("WHMCS"))
	die("This file cannot be accessed directly");

function create_forum_account($vars) {

    $firstname = $vars['firstname'];
    $lastname = $vars['lastname'];
    $email = $vars['email'];

    // Run code to create remote forum account here...

}

add_hook("ClientAdd",1,"create_forum_account");

*/

function setupRequest($authfile, $url, $requesttype, $postvalue, $debug)
{
	//logActivity('setupRequest Fired');	
	$ch = curl_init();

	$access_key = "28958032083094834";
	$headers = array('Content-type: application/json', 'Auth:'. $access_key);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	
	curl_setopt($ch, CURLOPT_USERAGENT, "WHMCS"); 
	curl_setopt($ch, CURLOPT_URL, $url); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	 if($requesttype == 'POST') {
	 	 curl_setopt($ch, CURLOPT_POST, 1);
	 }
	 else
	 {
	 	 curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $requesttype);
	 }

	 if($debug)
	 {
	 	 curl_setopt($ch, CURLOPT_PROXY, '192.168.4.1:8888');
	 }
	 curl_setopt($ch, CURLOPT_TIMEOUT, 10); 
	 curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3); 
	 curl_setopt($ch, CURLOPT_POSTFIELDS, $postvalue); 
	 $data = curl_exec($ch);	
	 return $ch;
}

function hook_create_a2billing_account($vars) {
	 $jsonarray = array('uid' => $vars['userid'], 'creditlimit' => 30, 'initialbalance' => 0.00, 'tariff' => 1, 'typepaid' => 1);
	 $json = json_encode($jsonarray);
	 
	 $url = 'https://backend-api.ciptex.net/callcard/'.$vars['userid'];
	 $ch = setupRequest('',$url, 'POST', $json, false);
	 $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); 
}
 
function hook_delete_a2billing_account($vars) {
	 $url = "https://backend-api.ciptex.net/callcard/".$vars['userid'];
	 $ch = setupRequest('', $url, 'DELETE','',false);
	 $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
}

function hook_create_inbound_number($vars) {
	if (server == true) {
	 $url = 'https://backend-api.ciptex.net/number/'.$vars['params']['domain'].'/setup';
	 $ch = setupRequest('',$url, 'POST',null,false);
	 $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	 
	 if($code == 200)
	 {
		$url = 'https://backend-api.ciptex.net/number/'.$vars['params']['clientsdetails']['userid'].'/'.$vars['params']['domain'].'/point';
		$ch = setupRequest('',$url,'GET',null,false);
		$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	 }
	}
}

function hook_suspend_number($vars) {
	if ($vars['params']['serverid'] == 2) {
	 $url = 'https://backend-api.ciptex.net/number/'.$vars['params']['domain'].'/suspend/'.$vars['params']['userid'];
	 $ch = setupRequest('',$url,'POST',null,false);
	 $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	}
}

function hook_unsuspend_number($vars) {
	if ($vars['params']['serverid'] == 2) {
	 $url = 'https://backend-api.ciptex.net/number/'.$vars['params']['domain'].'/unsuspend/'.$vars['params']['userid'];
	 $ch = setupRequest('',$url,'POST',null,false);
	 $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	}
}

function hook_extension_calculate($vars) {
	if(isset($vars['userid']))
	{
		$url = 'https://backend-api.ciptex.net/extencalculate/'.$vars['userid'];
	}
	else
	{
		$url = 'https://backend-api.ciptex.net/extencalculate/'.$vars['params']['userid'];
	}
	$ch = setupRequest('',$url,'GET',null,false);
	$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    logActivity($code.' hook extension_calculate fired. URL:'.$url);
}

//add_hook("ContactAdd",1,"hook_create_oauth_account_password2");

add_hook("AfterModuleCreate",1,"hook_create_inbound_number");
add_hook("AfterModuleCreate",2,"hook_extension_calculate");

add_hook("AfterModuleSuspend",1,"hook_suspend_number");
add_hook("AfterModuleSuspend",2,"hook_extension_calculate");

add_hook("AfterModuleUnsuspend",1,"hook_unsuspend_number");
add_hook("AfterModuleUnsuspend",2,"hook_extension_calculate");

add_hook("AdminClientServicesTabFieldsSave",1,"hook_extension_calculate");
add_hook("AfterConfigOptionsUpgrade",1,"hook_extension_calculate");

add_hook("ClientAdd",1,"hook_create_a2billing_account");
add_hook("ClientDelete",1,"hook_delete_a2billing_account");
?>