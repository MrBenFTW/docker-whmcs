<?php
/**
 * Example Hook Function
 *
 * Please refer to the documentation @ http://docs.whmcs.com/Hooks for more information
 * The code in this hook is commented out by default. Uncomment to use.
 *
 * @package    WHMCS
 * @author     WHMCS Limited <development@whmcs.com>
 * @copyright  Copyright (c) WHMCS Limited 2005-2013
 * @license    http://www.whmcs.com/license/ WHMCS Eula
 * @version    $Id$
 * @link       http://www.whmcs.com/
 */

/*

if (!defined("WHMCS"))
	die("This file cannot be accessed directly");

function create_forum_account($vars) {

    $firstname = $vars['firstname'];
    $lastname = $vars['lastname'];
    $email = $vars['email'];

    // Run code to create remote forum account here...

}

add_hook("ClientAdd",1,"create_forum_account");

*/

function hook_slack_open($vars) {
if(isset($vars['priority']))
{
	$intro = "New Ticket";
	if(isset($vars['replyid']) == true)
	{
		$intro = "User Reply";
	}
	
	$color = 'warning';
	switch($vars['priority']){
		case "Low":
			$color = 'good';
			break;
		case "Medium":
			$color = 'warning';
			break;
		case "High":
			$color = 'danger';
			break;
	}
	
	$jsonarray = array('text' => $intro.' in '.$vars['deptname'], 
					   'channel' => '#support', 
					   'icon_emoji' => ':sos:',
					   'attachments' => array(array('fallback' => $intro.' ['.$vars['priority'].']: <http://my.moretalk.uk.com/billingadmin/supporttickets.php?action=view&id='.$vars['ticketid'].'|Support Ticket>',
													'pretext' => $intro.' ['.$vars['priority'].']: <http://my.moretalk.uk.com/billingadmin/supporttickets.php?action=view&id='.$vars['ticketid'].'|Support Ticket>',
													'color' => $color,
													'fields' => array(array('title' => $vars['subject'],'value' => $vars['message'],'short' => false))
													)
											  )
					    );
}
else
{
	$jsonarray = array('text' => 'Ticket Closed', 
					   'channel' => '#support', 
					   'icon_emoji' => '+1',
					   'attachments' => array(array('fallback' => '<http://my.moretalk.uk.com/billingadmin/supporttickets.php?action=view&id='.$vars['ticketid'].'|Ticket '.$vars['ticketid'].' Closed>',
													'pretext' => '<http://my.moretalk.uk.com/billingadmin/supporttickets.php?action=view&id='.$vars['ticketid'].'|Ticket '.$vars['ticketid'].' Closed>',
													'color' => 'good',
													'fields' => array(array('title' => '','value' => 'Ticket Closed','short' => true))
													)
											  )
					    );
	
	
}
	$ch = setupRequest('', 'https://hooks.slack.com/services/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', 'POST', json_encode($jsonarray), false);
	$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);	
}

add_hook("TicketOpen",1,"hook_slack_open");
add_hook("TicketClose",1,"hook_slack_open");
add_hook("TicketOpenAdmin",1,"hook_slack_open");
add_hook("TicketUserReply",1,"hook_slack_open");
 
 ?>