<?php
$license = 'Leased-43a97364df5bc09e7f6f';
$db_host = 'apollo-web.cf8blo6oukfo.eu-west-2.rds.amazonaws.com';
$db_username = 'root';
$db_password = 'VAEm6XcX';
$db_name = 'ciptex_whmcs';
$cc_encryption_hash = 'apzt7BBQZ4eJZEpJQHDUN2QSw1wIgvE2KPFWbOyZhPNigHlsRNFyiVKcgt2tZfvX';
$templates_compiledir = 'templates_c';
$mysql_charset = 'utf8';
$api_access_key='sUyzAOf707';
$display_errors = true;