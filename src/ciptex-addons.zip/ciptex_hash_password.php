<?php
parse_str(file_get_contents('php://input'), $output);
if (password_verify($output["password"], $output["hash"]) == 1)
{
    echo 1;
}
else
{
    echo 0;
}
?>